-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2025 at 03:00 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `devsen_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'A',
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `address_text` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `status`, `name`, `surname`, `address_text`, `city`, `phone`, `email`, `date_create`, `date_update`) VALUES
(1, 'A', 'gabri', 'peress', 'via le italia 99', 'sesto san giovanni', '0212345', 'gabri@mail.com', '2025-10-25 09:18:17', '2025-10-25 15:27:46'),
(2, 'A', 'mario', 'rossi', 'piazza duomo 1', 'milano milano', '0245879', 'mario@rossi.com', '2025-10-25 11:58:25', '2025-10-25 15:34:52'),
(3, 'A', 'lucia', 'mondello', '', 'Lecco', '789', 'ma@sp.cc', '2025-10-25 15:57:26', '2025-10-25 15:57:26'),
(4, 'A', 'Renzo', 'detto lorenzo', 'via vai', 'Lecco', '12369', 'renzo@mail.ma', '2025-10-25 16:00:07', '2025-10-25 16:00:07'),
(5, 'D', 'Abbondio', 'Don', 'piazza chiesa', 'Lecco', '741258', 'abbondio@mail.ma', '2025-10-25 16:02:02', '2025-10-25 16:19:45'),
(6, 'D', 'Bravo', 'Quello', 'strada corto', 'Lecco', '78541', 'bravo@ma.ma', '2025-10-25 16:03:07', '2025-10-25 16:19:43'),
(7, 'D', 'Per', 'Petua', 'via canonica', 'Lecco', '1234', 'per@petua', '2025-10-25 16:05:25', '2025-10-25 16:18:18'),
(8, 'D', 'finale', 'tutto', 'bene', 'forse', '1234', 'aaa@aa.aa', '2025-10-25 16:06:25', '2025-10-25 16:14:34');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'A',
  `id_customer` int(11) NOT NULL COMMENT 'id della tabella customers',
  `date` date NOT NULL COMMENT 'data dell''ordine',
  `id_status` int(11) NOT NULL DEFAULT 0 COMMENT 'id della tabella orders_status',
  `total_amount` float NOT NULL DEFAULT 0,
  `date_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `status`, `id_customer`, `date`, `id_status`, `total_amount`, `date_create`, `date_update`) VALUES
(1, 'A', 1, '2025-10-26', 4, 98.99, '2025-10-25 20:39:47', '2025-10-25 21:20:29'),
(2, 'A', 1, '2025-10-27', 3, 23.33, '2025-10-25 21:33:13', '2025-10-25 21:50:27'),
(3, 'A', 2, '2025-10-26', 2, 25, '2025-10-25 21:35:31', '2025-10-25 21:50:25'),
(4, 'A', 3, '2025-10-26', 1, 100.99, '2025-10-25 21:36:54', '2025-10-25 21:36:54');

-- --------------------------------------------------------

--
-- Table structure for table `orders_status`
--

CREATE TABLE `orders_status` (
  `id` int(11) NOT NULL,
  `status_label` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders_status`
--

INSERT INTO `orders_status` (`id`, `status_label`) VALUES
(1, 'in_attesa'),
(2, 'in_lavorazione'),
(3, 'completato'),
(4, 'annullato');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_status`
--
ALTER TABLE `orders_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders_status`
--
ALTER TABLE `orders_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
